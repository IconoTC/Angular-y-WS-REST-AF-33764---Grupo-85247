import { Component } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  idioma: string = 'es';

  constructor(private translateService: TranslateService){
    // Indicamos el idioma por defecto en la aplicacion
    translateService.setDefaultLang(this.idioma);
  }

  cambiarIdioma(nuevoIdioma: string){
    this.idioma = nuevoIdioma;

    // Forzamos el cambio de idioma
    this.translateService.use(this.idioma);
  }
}
