import { Component} from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {

  mostrar: boolean = false;
  email: string | null = null;

  constructor(private loginService: LoginService) { 
    loginService.comprobarLogado().subscribe(user => {
      if (user) {
        console.log('Usuario autenticado:', user.email);
        this.mostrar = true;
        this.email = user.email;
      } else {
        console.log('No hay usuario autenticado.');
        this.email = null;
      }
    });
  }

  salir(){
    this.loginService.logout()
      .then(() => {
        alert("Sesion cerrada");
        this.mostrar = false;
      })
  }

}
