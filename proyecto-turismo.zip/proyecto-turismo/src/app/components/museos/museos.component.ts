import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Museo } from 'src/app/models/museo';
import { MuseosService } from 'src/app/services/museos.service';

@Component({
  selector: 'app-museos',
  templateUrl: './museos.component.html',
  styleUrls: ['./museos.component.css']
})
export class MuseosComponent implements AfterViewInit {

  museos: Museo[] = [];
  dataSource: any;
  displayedColumns = ['nombre', 'abierto', 'horario', 'precio'];  // propiedades del museo
  dato: string = '';

  // Se inyecta cuando ya se ve la tabla en el navegador
  @ViewChild(MatPaginator)
  paginator: MatPaginator | undefined;

  @ViewChild(MatSort)
  sort: MatSort | undefined;

  constructor(private museosService: MuseosService) { 
    this.museos = museosService.getAll();
    this.dataSource = new MatTableDataSource(this.museos);
  }

  filtrar(){
    this.dataSource.filter = this.dato.toLowerCase();
  }

  ngAfterViewInit(): void {
    // Añadir el paginator al dataSource
    if (this.paginator != undefined){
      this.dataSource.paginator = this.paginator;
    }

    // Añadir el sort al dataSource
    if (this.sort != undefined){
      this.dataSource.sort = this.sort;
    }

    // Para poder filtrar solo por el nombre del museo
    this.dataSource.filterPredicate = (item: Museo, filter: string) => {
      return item.nombre.toLowerCase().includes(filter);
    }
  }


}
