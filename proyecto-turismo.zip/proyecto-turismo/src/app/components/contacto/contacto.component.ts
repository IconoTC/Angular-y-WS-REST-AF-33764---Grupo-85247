import { ContactoService } from './../../services/contacto.service';
import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent{

  contactoForm: FormGroup = new FormGroup({
    nombre:  new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6,7,9]{1}[0-9]{8}')]),
    email: new FormControl('', [Validators.required, Validators.email]),
    asunto: new FormControl('', [Validators.required, Validators.minLength(5)]),
    mensaje: new FormControl('', [Validators.required, Validators.minLength(10)])
  });

  constructor(private contactoService: ContactoService, private translateService: TranslateService) { }

  guardar(): void{
    this.contactoService.enviar(this.contactoForm.value)
      .then(() => {
        this.contactoForm.reset();
        alert(this.translateService.instant('contacto.msg'));
      })
      .catch(error => {
        console.log(error)
      })
  }

}
