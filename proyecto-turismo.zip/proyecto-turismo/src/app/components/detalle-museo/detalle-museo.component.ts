import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Museo } from 'src/app/models/museo';
import { MuseosService } from 'src/app/services/museos.service';

@Component({
  selector: 'app-detalle-museo',
  templateUrl: './detalle-museo.component.html',
  styleUrls: ['./detalle-museo.component.css']
})
export class DetalleMuseoComponent implements OnInit {

  id: number = 0;
  museo?: Museo;

  constructor(private ruta: ActivatedRoute, private museosService: MuseosService) {

    // Recuperar el parametro id
    this.id = ruta.snapshot.params['id'];

    // buscar el museo en museosService
    // lo guardas en la variable museo
    this.museo = museosService.buscarMuseo(this.id);

   }

  ngOnInit(): void {
  }

}
