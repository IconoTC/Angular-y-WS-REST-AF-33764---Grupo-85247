import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-c3',
  templateUrl: './c3.component.html',
  styleUrls: ['./c3.component.css']
})
export class C3Component implements OnInit {

  hotel: string = '';
  entrada: string = '';
  salida: string = '';
  habitaciones: number = 0;

  constructor(private ruta: ActivatedRoute) { 
    console.log(ruta)

    // Recuperar el parametro de la ruta
    // Con el mismo nombre que se ha declado en el app.module.ts 'c3/:hotel'
    this.hotel = ruta.snapshot.params['hotel'];

    // Recuperar los query params
    // Con el mismo nombre que se han enviado en [queryParams]
    this.entrada = ruta.snapshot.queryParams['entrada'];
    this.salida = ruta.snapshot.queryParams['salida'];
    this.habitaciones = ruta.snapshot.queryParams['habitaciones'];

  }

  ngOnInit(): void {
  }

}
