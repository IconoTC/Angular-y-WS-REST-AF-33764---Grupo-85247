import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  email: string = '';
  pw: string = '';
  confPw: string = '';
  registro: boolean = false;

  constructor(private loginService: LoginService) { }

  login(){
    this.loginService.login(this.email, this.pw)
      .then(() => {
        alert("Usuario logado");
      })
      .catch(error => {
        console.log(error);
        alert("Credenciales no validas o no estas registrado");
      })
  }

  registrarme(){
    if (this.pw == this.confPw && this.pw.length >= 6){
      this.loginService.registro(this.email, this.pw)
        .then(() => {
          alert("Usuario creado");
        })
        .catch(error => {
          console.log(error);
        })
    } else {
      alert("El pw y la confirmacion no son iguales o tienen menos de 6 caracteres");
    }
  }

}
