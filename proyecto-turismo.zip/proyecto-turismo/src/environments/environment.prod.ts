export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDE3qU_qg6oUjZhGqypMa6glnOprY73h4U",
    authDomain: "anabel-indra-30-octubre.firebaseapp.com",
    projectId: "anabel-indra-30-octubre",
    storageBucket: "anabel-indra-30-octubre.firebasestorage.app",
    messagingSenderId: "1041242700317",
    appId: "1:1041242700317:web:455c609f1ef011834de4f4"
  }
};
