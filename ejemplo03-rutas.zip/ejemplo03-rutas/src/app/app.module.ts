import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';

import { C1Component } from './components/c1/c1.component';
import { C2Component } from './components/c2/c2.component';
import { C3Component } from './components/c3/c3.component';
import { RouterModule, Routes } from '@angular/router';

// Crear el array de rutas fuera del modulo
const misRutas: Routes = [
  {path: 'c1', component: C1Component},
  {path: 'c2', component: C2Component},
  {path: 'c3/:hotel', component: C3Component}
];

@NgModule({
  declarations: [
    AppComponent,
    C1Component,
    C2Component,
    C3Component
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
