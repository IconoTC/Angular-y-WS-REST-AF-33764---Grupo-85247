// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDE3qU_qg6oUjZhGqypMa6glnOprY73h4U",
    authDomain: "anabel-indra-30-octubre.firebaseapp.com",
    projectId: "anabel-indra-30-octubre",
    storageBucket: "anabel-indra-30-octubre.firebasestorage.app",
    messagingSenderId: "1041242700317",
    appId: "1:1041242700317:web:455c609f1ef011834de4f4"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
