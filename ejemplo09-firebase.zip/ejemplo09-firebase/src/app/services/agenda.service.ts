import { Injectable } from '@angular/core';
import { Action, AngularFirestore, DocumentChangeAction, DocumentReference, DocumentSnapshot } from '@angular/fire/compat/firestore';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {

  private db = "/agenda";

  constructor(private angularFirestore: AngularFirestore) { }

  getAll(): Observable<DocumentChangeAction<unknown>[]>{
    return this.angularFirestore.collection(this.db).snapshotChanges();
  }

  nuevoAmigo(nuevo: any): Promise<DocumentReference<unknown>>{
    return this.angularFirestore.collection(this.db).add(nuevo);
  }

  buscarAmigo(id: string): Observable<Action<DocumentSnapshot<unknown>>>{
    return this.angularFirestore.collection(this.db).doc(id).snapshotChanges();
  }

  eliminarAmigo(id: string): Promise<void>{
    return this.angularFirestore.collection(this.db).doc(id).delete();
  }

  modificarAmigo(id: string, amigo: any): Promise<void>{
    return this.angularFirestore.collection(this.db).doc(id).set(amigo);
  }
}
