import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EquipoService {

  //url: string = "https://rickandmortyapi.com/api/character";
  url: string = "https://hp-api.onrender.com/api/characters";
  cabeceras: HttpHeaders = new HttpHeaders({'Content-type':'application/json'});

  constructor(private http: HttpClient) { }

  getAll(): Observable<any>  {
    // Si utilizais el servicio rest de Harry Potter, hay que quitar las cabeceras
     return this.http.get(this.url);

    //return this.http.get(this.url, {headers: this.cabeceras});
  }  
}
